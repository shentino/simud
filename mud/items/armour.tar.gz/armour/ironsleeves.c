#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(1/2);
   set_ac_mod( (["slashing":2/3,"electric":-1]) );
   set_requirement( (["str":5]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(300);
   set_name( "iron chain sleeves" );
   set_alt_name( ({"iron sleeves", "sleeves", "chain sleeves"}) );
   set_distant( "a pair of iron chain sleeves" );
   set_look( "Scale-mail at the shoulder, but iron chain down the length of the arm, these sleeves protect you quite well.");
   set_specific( "the iron sleeves" );
   set_plural( "pairs of iron chain sleeves" );
   set_armour_type( "armour" );
   set_type( "sleeves" );
   set_weight( 18000 ); // 18 kg = 40 lbs
   set_flexible(1);
   set_size(20);
   set_body_parts(BP_ARMS);
}
mapping query_aspects() {
   return ([ C_CLOTHING, C_SLEEVES, C_METAL, C_IRON, C_CHAIN ]);
}
