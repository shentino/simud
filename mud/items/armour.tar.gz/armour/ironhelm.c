#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(1/2);
   set_ac_mod( (["edged":1, "blunt":3/2,"electric":-2]) );
   set_requirement( (["str":10]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(250);
   set_name( "iron helm" );
   set_alt_name( ({"helmet","helm","Iron Helm"}) );
   set_distant( "an iron helm" );
   set_look( "Made completely of iron, this helm is a good deterrence for blades, but does not provide much defense from stabbing weapons. This is the perfect helmet for the thrifty warrior.");
   set_specific( "the iron helm" );
   set_plural( "Iron War Helms" );
   set_armour_type( "armour" );
   set_type( "helmet" );
   set_weight( 5400 ); // 5.4 kg = 12 lbs
   set_flexible(1);
   set_size(20);
   set_body_parts(BP_HEAD);
}
mapping query_aspects() {
   return ([ C_CLOTHING, C_HEADGEAR, C_METAL, C_IRON ]);
}
