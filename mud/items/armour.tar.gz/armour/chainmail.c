#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(1);
   set_ac_mod( (["edged":2,"piercing":1/4,"electric":-2]) );
   set_requirement( (["str":13]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(1000);
   set_name( "chainmail" );
   set_alt_name( ({"mail","suit","armour","armor"}) );
   set_distant( "a suit of chainmail" );
   set_look( "This is a shirt of armour made by interlocking links of iron "+
             "chain together. You might be able to get some use out of it "+
             "by wearing the durned thing and hoping that it stops swords "+
             "from cutting you wide open.");
   set_specific( "the chainmail" );
   set_plural( "suits of chainmails" );
   set_armour_type( "armour" );
   set_type( "armour" );
   set_weight( 7200 );   // 7.2 kg = 16 lbs
   set_flexible(1);
   set_size(20);
   set_body_parts(BP_TORSO);
}
int query_use_bonuses()
{
   return (query_worn());
}
int query_dex_bonus()
{
   return -2/3;
}
mapping query_aspects() {
   return ([ C_CLOTHING, C_SHIRT, C_METAL, C_IRON, C_CHAIN ]);
}
