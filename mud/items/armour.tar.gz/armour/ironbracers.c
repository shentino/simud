#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(1);
   set_ac_mod( (["slashing":4,"electric":-2]) );
   set_requirement( (["str":3]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(160);
   set_name( "iron bracers" );
   set_alt_name( ({"bracers"}) );
   set_distant( "a pair of iron bracers" );
   set_look( "Two plates of metal curved to fit your wrist and held on with soft leather straps.");
   set_specific( "the iron bracers" );
   set_plural( "pairs of iron bracers" );
   set_armour_type( "armour" );
   set_type( "bracers" );
   set_weight( 3600 ); // 3.6 kg = 8 lbs
   set_flexible(0);
   set_size(5);
   set_body_parts(BP_WRISTS);
}

mapping query_aspects() {
   return ([ C_CLOTHING, C_BRACERS, C_METAL, C_IRON, C_CLOTH, C_LEATHER ]);
}
