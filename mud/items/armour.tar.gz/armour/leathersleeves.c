#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(1/3);
   set_ac_mod( (["ice":1]) );
   set_requirement( (["str":4]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(70);
   set_name( "leather sleeves" );
   set_alt_name( ({"sleeves"}) );
   set_distant( "a pair of leather sleeves" );
   set_look( "Long leather sleeves designed to keep your arms farm, and also protect your arms while shooting a bow.");
   set_specific( "the leather sleeves" );
   set_plural( "pairs of leather sleeves" );
   set_armour_type( "armour" );
   set_type( "bracers" );
   set_weight( 18000 ); // 18 kg = 40 lbs
   set_flexible(0);
   set_size(20);
   set_body_parts(BP_ARMS);
}

mapping query_aspects() {
   return ([ C_CLOTHING, C_SLEEVES, C_CLOTH, C_LEATHER ]);
}
