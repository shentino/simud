#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(1);
   set_ac_mod( (["edged":1,"electric":-1]) );
   set_requirement( (["str":10]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(150);
   set_name( "iron gauntlets" );
   set_alt_name( ({"gauntlets","gloves","gauntlet"}) );
   set_distant( "a pair of iron gauntlets" );
   set_look( "Made completely of iron, these gauntlets are a good deterrence for blades, and protect your hands quite well. These are the perfect gauntlets for the thrifty warrior.");
   set_specific( "the iron gauntlets" );
   set_plural( "pairs of iron gauntlets" );
   set_armour_type( "armour" );
   set_type( "gauntlets" );
   set_weight( 3150 ); // 3.15 kg = 7 lbs
   set_flexible(1);
   set_size(5);
   set_body_parts(BP_HANDS);
}

int query_use_bonuses()
{
   return (query_worn());
}
int query_dex_bonus()
{
   return -3/4;
}
mapping query_aspects() {
   return ([ C_CLOTHING, C_GLOVES, C_METAL, C_IRON ]);
}
