#include <const.h>

#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(2/3);
   set_ac_mod( (["ice":2]) );
   set_requirement( (["str":6]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(90);
   set_name( "loose leather pants" );
   set_alt_name( ({"pants", "leather pants", "loose pants"}) );
   set_distant( "a pair of loose leather pants" );
   set_look( "Cured leather, these pants are loose and make no sound as you move.");
   set_specific( "the leather pants" );
   set_plural( "pairs of loose leather pants" );
   set_armour_type( "armour" );
   set_type( "leggings" );
   set_weight( 18000 ); // 18 kg = 40 lbs
   set_flexible(1);
   set_size(20);
   set_body_parts(BP_LEGS);
}

mapping query_aspects() {
   return ([ C_CLOTHING, C_PANTS, C_CLOTH, C_LEATHER ]);
}
