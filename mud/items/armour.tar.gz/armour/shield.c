#include <const.h>
#include <const/raceconst.h>
inherit "/battle/shield";

void create() {
   ::create();
   set_base_ac(1);
   set_ac( (["edged":1,"piercing":1]) );
   set_name( "shield" );
set_value(360);
   set_distant( "a small shield" );
   set_look("This is a small iron shield. Perhaps if you were to strap it on"+
            "to your arm, you might manage to deflect swords and stuff.");
   set_specific( "the shield" );
   set_plural( "shields" );
   set_weight( 2700 ); // 2.7 kg = 6 lbs
}

mapping query_aspects() {
   return ([ C_METAL, C_IRON, C_SHIELD ]);
}
