#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(1);
   set_ac_mod( (["ice":2]) );
   set_requirement( (["str":8]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(120);
   set_name( "leather jerkin" );
   set_alt_name( ({"jerkin", "Leather Jerkin"}) );
   set_distant( "a leather jerkin" );
   set_look( "A fitted leather jerkin, full of pouches and lined with soft fur.");
   set_specific( "the leather jerkin" );
   set_plural( "leather jerkins" );
   set_armour_type( "armour" );
   set_type( "armour" );
   set_weight( 18000 ); // 18 kg = 40 lbs
   set_flexible(1);
   set_size(20);
   set_body_parts(BP_TORSO | BP_ARMS);
}
mapping query_aspects() {
   return ([ C_CLOTHING, C_JERKIN, C_CLOTH, C_LEATHER ]);
}
