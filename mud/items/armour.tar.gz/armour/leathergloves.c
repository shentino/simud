#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(0);
   set_ac_mod( (["ice":1]) );
   set_requirement( (["str":2]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(30);
   set_name( "leather gloves" );
   set_alt_name( ({"gauntlets","gloves","gauntlet"}) );
   set_distant( "a pair of leather gloves" );
   set_look( "Soft leather gloves which warm your hands and look really cool.");
   set_specific( "the leather gloves" );
   set_plural( "pairs of leather gloves" );
   set_armour_type( "armour" );
   set_type( "gauntlets" );
   set_weight( 300 );
   set_flexible(1);
   set_size(20);
   set_body_parts(BP_HANDS);
}

mapping query_aspects() {
   return ([ C_CLOTHING, C_GLOVES, C_CLOTH, C_LEATHER ]);
}
