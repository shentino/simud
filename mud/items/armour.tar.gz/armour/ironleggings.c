#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(2/3);
   set_ac_mod( (["slashing":1, "lightning":-1]) );
   set_requirement( (["str":8]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(360);
   set_name( "iron leggings" );
   set_alt_name( ({"Iron Leggings", "iron leggings", "leggings"}) );
   set_distant( "a pair of iron leggings" );
   set_look( " Jointed plates of iron, curved to fit your legs and strapped on with soft leather. Good for deflecting slashing blows, not good for much else.");
   set_specific( "the iron leggings" );
   set_plural( "pairs of iron leggings" );
   set_armour_type( "armour" );
   set_type( "leggings" );
   set_weight( 18000 ); // 18 kg = 40 lbs
   set_flexible(0);
   set_size(20);
   set_body_parts(BP_LEGS);
}
int query_use_bonuses()
{
   return(query_worn());
}
int query_dex_bonus()
{
   return -1;
}
int query_spd_bonus()
{
   return -2;
}
mapping query_aspects() {
   return ([ C_CLOTHING, C_PANTS, C_METAL, C_IRON, C_CLOTH, C_LEATHER ]);
}
