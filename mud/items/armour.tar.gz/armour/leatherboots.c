#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(0);
   set_ac_mod( (["ice":1/2]) );
   set_requirement( (["str":2]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(50);
   set_name( "leather boots" );
   set_alt_name( ({"boots"}) );
   set_distant( "a pair of leather boots" );
   set_look( "Fashioned of soft leather, these boots warm your feet but do little else..");
   set_specific( "the leather boots" );
   set_plural( "pairs of leather boots" );
   set_armour_type( "armour" );
   set_type( "boots" );
   set_weight( 450 ); // .45 kg=1 lb
   set_flexible(0);
   set_size(20);
   set_body_parts(BP_FEET);
}

mapping query_aspects() {
   return ([ C_CLOTHING, C_SHOES, C_METAL, C_IRON, C_CLOTH, C_LEATHER ]);
}
