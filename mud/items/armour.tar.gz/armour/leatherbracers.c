#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(1/4);
   set_ac_mod( (["slashing":1/2]) );
   set_requirement( (["str":1]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(60);
   set_name( "leather bracers" );
   set_alt_name( ({"bracers"}) );
   set_distant( "a pair of leather bracers" );
   set_look( "Stiff leather with designs of twisted knots carved into it... it's held on by laces up the back.");
   set_specific( "the leather bracers" );
   set_plural( "pairs of leather bracers" );
   set_armour_type( "armour" );
   set_type( "bracers" );
   set_weight( 400 ); // .45kg=1 lb
   set_flexible(0);
   set_size(20);
   set_body_parts(BP_WRISTS);
}
mapping query_aspects() {
   return ([ C_CLOTHING, C_BRACERS, C_CLOTH, C_LEATHER ]);
}
