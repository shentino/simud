#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(2/3);
   set_ac_mod( (["edged":4/5, "blunt":2/3,"electric":-2]) );
   set_requirement( (["str":11]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(490);
   set_name( "Iron War Helm" );
   set_alt_name( ({"helmet","helm","war helm", "iron war helm", "Iron war helm", "Iron War helm"}) );
   set_distant( "an Iron War Helm" );
   set_look( "A helm for the advanced warrior; special ridges help guide sword blows away from the head, and reinforcements inside prevent crushing blows. A very strong helmet.");
   set_specific( "the Iron War Helm" );
   set_plural( "Iron War Helms" );
   set_armour_type( "armour" );
   set_type( "helmet" );
   set_weight( 18000 ); // 18 kg = 40 lbs
   set_flexible(1);
   set_size(20);
   set_body_parts(BP_HEAD);
}

mapping query_aspects() {
   return ([ C_CLOTHING, C_HEADGEAR, C_METAL, C_IRON ]);
}
