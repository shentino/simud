#include <const.h>
#include <const/raceconst.h>
inherit "/battle/armour";

void create() {
   ::create();
   set_base_ac(1/4);
   set_ac_mod( (["electric":-1/3]) );
   set_requirement( (["str":6]) );
   set_gettable( 1 );
   set_droppable( 1 );
set_value(130);
   set_name( "iron boots" );
   set_alt_name( ({"boots"}) );
   set_distant( "a pair of iron boots" );
   set_look( "This footwear is made of solid iron plates, held together with bolts. They are fairly heavy, but protect your feet quite well.");
   set_specific( "the iron boots" );
   set_plural( "pairs of iron boots" );
   set_armour_type( "armour" );
   set_type( "boots" );
   set_weight( 13500 ); // 13.5 kg = 30 lbs
   set_flexible(0);
   set_size(5);
   set_body_parts(BP_FEET);
}

int query_use_bonuses()
{
   return (query_worn());
}
int query_dex_bonus()
{
   return -1;
}
int query_spd_bonus()
{
   return -1;
}

mapping query_aspects() {
   return ([ C_CLOTHING, C_SHOES, C_METAL, C_IRON ]);
}
